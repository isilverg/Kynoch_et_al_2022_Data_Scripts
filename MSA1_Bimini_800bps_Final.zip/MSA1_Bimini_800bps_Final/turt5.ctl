Bimini Green Turtle MSA
rookeries.txt
foragingground_7_6_21_unlabelled.txt
turt5.sum
stockproportions5.bot
turt5.frq
turt5.b01
individualstockassign5.cls
turt5.rgn
1666
8
1
3264066
4512562
90032345
1
1
1
(26I1)
(3I4,26I4)
T T F T T F F
  1 26  F  mtDNA
  1  1 .250000  Tortuguero   .007143
  2  2 .250000  Rancho Nuevo .007143
  3  3 .250000  Quintana Roo .007143
  4  4 .250000  SW Cuba      .007143
  5  5 .250000  S. Florida   .950000
  6  6 .250000  CE Florida   .007143
  7  7 .250000  Aves Island  .007143
  8  8 .250000  Surinam      .007143