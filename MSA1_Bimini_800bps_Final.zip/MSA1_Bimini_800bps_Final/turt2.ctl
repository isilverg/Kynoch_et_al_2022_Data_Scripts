Bimini Green Turtle MSA
rookeries.txt
foragingground_7_6_21_unlabelled.txt
turt2.sum
stockproportions2.bot
turt2.frq
turt2.b01
individualstockassign2.cls
turt2.rgn
1266
8
1
3495066
11257
93767125
1
1
1
(26I1)
(3I4,26I4)
T T F T T F F
  1 26  F  mtDNA
  1  1 .250000  Tortuguero   .007143
  2  2 .250000  Rancho Nuevo .950000
  3  3 .250000  Quintana Roo .007143
  4  4 .250000  SW Cuba      .007143
  5  5 .250000  S. Florida   .007143
  6  6 .250000  CE Florida   .007143
  7  7 .250000  Aves Island  .007143
  8  8 .250000  Surinam      .007143