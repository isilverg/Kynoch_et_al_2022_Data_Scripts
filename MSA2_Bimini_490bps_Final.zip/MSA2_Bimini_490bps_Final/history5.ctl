Bimini Green Turtle MSA with 490 BP 
rookeries_shamblin_490.txt
foragingground490_7_6_21_unlabelled.txt
history5.sum
proportions5.bot
history5.frq
history5.b01
individualassign5.cls
history5.rgn
7050
9
1
3205066
923842
82905
1
1
1
(18I1)
(3I4,18I4)
T T F T T F F
  1 18  F  mtDNA
  1  1 .250000  Tortuguero   .00625    
  2  2 .250000  Quintana Roo .00625
  3  3 .250000  Aves Island  .00625
  4  4 .250000  Surinam      .00625
  5  5 .250000  Florida      .95000
  6  6 .250000  Brazil       .00625
  7  7 .250000  Ascension    .00625
  8  8 .250000  Ginuea       .00625
  9  9 .250000  Cyprus       .00625
