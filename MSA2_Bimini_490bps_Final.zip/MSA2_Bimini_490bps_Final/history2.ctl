Bimini Green Turtle MSA with 490 BP 
rookeries_shamblin_490.txt
foragingground490_7_6_21_unlabelled.txt
history2.sum
proportions2.bot
history2.frq
history2.b01
individualassign2.cls
history2.rgn
2286
9
1
92834
23409
675304
1
1
1
(18I1)
(3I4,18I4)
T T F T T F F
  1 18  F  mtDNA
  1  1 .250000  Tortuguero   .006250
  2  2 .250000  Quintana Roo .950000
  3  3 .250000  Aves Island  .006250
  4  4 .250000  Surinam      .006250
  5  5 .250000  Florida      .006250
  6  6 .250000  Brazil       .006250
  7  7 .250000  Ascension    .006250
  8  8 .250000  Ginuea       .006250
  9  9 .250000  Cyprus       .006250
